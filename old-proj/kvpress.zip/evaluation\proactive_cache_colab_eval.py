# ============================================================
# ProactiveCachePress — KVPress Leaderboard Evaluation
# Google Colab Notebook (copy-paste ready, cell-by-cell)
#
# Paper:   https://openreview.net/forum?id=UsdzvxDZUO
# Zenodo:  https://doi.org/10.5281/zenodo.20465914
# Code:    https://github.com/skhavin/proactive-cache
# Author:  S. Khavin — Independent Researcher, Chennai, India
#
# Evaluates ProactiveCachePress on the RULER dataset (4096 context)
# with meta-llama/Llama-3.1-8B-Instruct, exactly as required by
# the kvpress leaderboard submission guide.
# ============================================================


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 1 — Clone kvpress from source and install in            ║
# ║          EDITABLE mode so injected files are picked up       ║
# ╚══════════════════════════════════════════════════════════════╝
"""
!git clone --quiet https://github.com/NVIDIA/kvpress.git
%cd kvpress
!pip install -q -e .
!pip install -q fire pyyaml tqdm datasets accelerate
"""
# After running the above, restart the runtime if prompted.
# Then continue from Cell 2.


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 2 — Write ProactiveCachePress into the editable         ║
# ║          kvpress source tree                                  ║
# ╚══════════════════════════════════════════════════════════════╝
import importlib, importlib.util, pathlib, subprocess, sys

# ── Robust kvpress root detection (handles wheel, editable, namespace pkg) ──
def _find_kvpress_root() -> pathlib.Path:
    # Strategy 1: find_spec on the presses subpackage (most reliable)
    spec = importlib.util.find_spec("kvpress.presses")
    if spec and spec.submodule_search_locations:
        return pathlib.Path(list(spec.submodule_search_locations)[0]).parent

    # Strategy 2: find_spec on kvpress itself
    spec = importlib.util.find_spec("kvpress")
    if spec and spec.origin:
        return pathlib.Path(spec.origin).parent

    # Strategy 3: pip show kvpress → Location field
    result = subprocess.run(
        [sys.executable, "-m", "pip", "show", "kvpress"],
        capture_output=True, text=True
    )
    for line in result.stdout.splitlines():
        if line.startswith("Location:"):
            loc = line.split(":", 1)[1].strip()
            candidate = pathlib.Path(loc) / "kvpress"
            if candidate.exists():
                return candidate

    raise RuntimeError(
        "Cannot locate kvpress installation. "
        "Make sure you ran:  !pip install -e kvpress/"
    )

KVPRESS_ROOT = _find_kvpress_root()
PRESSES_DIR  = KVPRESS_ROOT / "presses"
PRESS_FILE   = PRESSES_DIR / "proactive_cache_press.py"

print(f"kvpress root : {KVPRESS_ROOT}")
print(f"Writing press: {PRESS_FILE}")

PRESS_CODE = '''\
# SPDX-License-Identifier: Apache-2.0
# ProactiveCachePress — S. Khavin (2025)
# Paper:  https://openreview.net/forum?id=UsdzvxDZUO
# Zenodo: https://doi.org/10.5281/zenodo.20465914
# GitHub: https://github.com/skhavin/proactive-cache

import logging
import pickle
from dataclasses import dataclass, field
from typing import Optional

import torch
from torch import nn
from kvpress.presses.scorer_press import ScorerPress

logger = logging.getLogger(__name__)


@dataclass
class ProactiveCachePress(ScorerPress):
    """
    Proactive KV Cache Eviction via offline attention-head prototypes.

    Unlike reactive methods (StreamingLLM, H2O, SnapKV) that score tokens
    after computing full attention, Proactive Cache profiles a frozen model
    offline, clusters per-head attention patterns into K-Means prototype
    centroids, and predicts which tokens to retain before any query arrives.
    Tokens are evicted at ingest — never written to cache — bounding decode
    attention to O(B^2) = O(1) in sequence length.

    Architecture (three phases):
        1. Offline calibration : K-Means on attention patterns of ~300 docs,
                                  4 centroids per (layer, head) pair.
        2. Inference scoring   : Position-based score from centroid histograms.
                                  O(n) lookup, no query access required.
        3. Split-budget eviction: 4 sink tokens + 50% contiguous recency window
                                  + remaining budget for prototype-guided tokens.
                                  Maintains RoPE positional coherence.

    Parameters
    ----------
    compression_ratio : float, default=0.0
        Fraction of KV pairs to evict. e.g. 0.75 keeps only 25% of tokens.
    prototype_path : str, optional
        Path to a .pkl file from ProactiveCache.profile(). If None or not
        found, falls back to attention-sink + recency scoring only.
    n_sink : int, default=4
        Number of initial tokens unconditionally preserved (attention sinks).

    Example
    -------
    # Sink+recency fallback (no prototype file needed — runs on any machine)
    press = ProactiveCachePress(compression_ratio=0.75)

    # Full method with prototypes
    press = ProactiveCachePress(
        compression_ratio=0.75,
        prototype_path="/content/llama3.1_8b_prototypes.pkl",
    )

    with press(model):
        outputs = model.generate(**inputs)

    References
    ----------
    S. Khavin (2025). Proactive KV Cache Eviction for Training-Free O(1)
    Inference in Autoregressive Transformers.
    OpenReview : https://openreview.net/forum?id=UsdzvxDZUO
    Zenodo DOI : https://doi.org/10.5281/zenodo.20465914
    pip install : proactive-cache
    """

    compression_ratio: float = 0.0
    prototype_path: Optional[str] = None
    n_sink: int = 4

    _prototypes: Optional[dict] = field(default=None, init=False, repr=False)
    _score_cache: dict = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self):
        super().__post_init__()
        self._prototypes = None
        self._score_cache = {}
        if self.prototype_path:
            try:
                with open(self.prototype_path, "rb") as f:
                    self._prototypes = pickle.load(f)
                logger.info(
                    f"[ProactiveCachePress] Loaded {len(self._prototypes)} "
                    f"prototypes from \'{self.prototype_path}\'"
                )
            except FileNotFoundError:
                logger.warning(
                    f"[ProactiveCachePress] Prototype file not found: "
                    f"\'{self.prototype_path}\'. Using sink+recency fallback."
                )
        else:
            logger.info(
                "[ProactiveCachePress] No prototype_path given. "
                "Using attention-sink + recency fallback scoring."
            )

    def _compute_position_scores(
        self, seq_len: int, budget: int, device: torch.device
    ) -> torch.Tensor:
        """
        O(n) position-based importance scores, cached per (seq_len, budget).

        Score layout (higher = keep):
          - Sink positions [0 : n_sink]          : peak * 100
          - Prototype-guided middle positions     : centroid cumsum score
          - Recency window [tail 50% of budget]  : peak * 50
          - All others                            : small base score / 0
          - Deterministic tiebreaker             : linspace(0, 1e-4, seq_len)
        """
        cache_key = (seq_len, budget)
        if cache_key in self._score_cache:
            return self._score_cache[cache_key].to(device)

        scores = torch.zeros(seq_len, dtype=torch.float32)

        # Prototype-guided scoring (only when prototypes are loaded)
        if self._prototypes is not None:
            for (layer, head), data in self._prototypes.items():
                centroid = torch.as_tensor(
                    data["centroids"][0], dtype=torch.float32
                )
                max_d = min(len(centroid), seq_len)
                if max_d == 0:
                    continue
                cumsum = centroid[:max_d].cumsum(dim=0)
                for p in range(seq_len):
                    reach = min(max_d, seq_len - p)
                    if reach > 0:
                        scores[p] += cumsum[reach - 1]

        peak = scores.max().item() if scores.max().item() > 0.0 else 1.0

        # Attention sink boost
        scores[: min(self.n_sink, seq_len)] += peak * 100.0

        # Recency window boost (50% of budget at the tail)
        recency = min(max(8, budget // 2), seq_len)
        scores[seq_len - recency :] += peak * 50.0

        # Deterministic tiebreaker (prefer later tokens among equals)
        scores += torch.linspace(0, 1e-4, seq_len)

        self._score_cache[cache_key] = scores
        return scores.to(device)

    def score(
        self,
        module: nn.Module,
        hidden_states: torch.Tensor,
        keys: torch.Tensor,
        values: torch.Tensor,
        attentions: torch.Tensor,
        kwargs,
    ) -> torch.Tensor:
        """
        KVPress ScorerPress hook — called once per attention layer at prefill.

        Returns (batch, num_kv_heads, seq_len) importance scores.
        Higher score = keep the token. Query-free, O(n) per layer.
        """
        batch_size, num_kv_heads, seq_len, _ = keys.shape
        budget = max(self.n_sink + 1, int(seq_len * (1.0 - self.compression_ratio)))
        device = keys.device

        pos_scores = self._compute_position_scores(seq_len, budget, device)
        scores = (
            pos_scores.unsqueeze(0)
                      .unsqueeze(0)
                      .expand(batch_size, num_kv_heads, seq_len)
        )
        return scores.contiguous()
'''

PRESS_FILE.write_text(PRESS_CODE)
print(f"Written: {PRESS_FILE}")

# Patch kvpress/__init__.py to export ProactiveCachePress
INIT_FILE = KVPRESS_ROOT / "__init__.py"
init_text = INIT_FILE.read_text()

if "ProactiveCachePress" not in init_text:
    init_text = init_text.replace(
        "from kvpress.presses.scorer_press import ScorerPress",
        "from kvpress.presses.proactive_cache_press import ProactiveCachePress\n"
        "from kvpress.presses.scorer_press import ScorerPress",
    )
    init_text = init_text.replace(
        '"ScorerPress",',
        '"ProactiveCachePress",\n    "ScorerPress",',
    )
    INIT_FILE.write_text(init_text)
    print("Patched: kvpress/__init__.py")
else:
    print("kvpress/__init__.py already has ProactiveCachePress")

# Force Python to reload the module from the updated source
import kvpress.presses
importlib.invalidate_caches()

# Re-import fresh
from kvpress.presses.proactive_cache_press import ProactiveCachePress
from kvpress import ProactiveCachePress as _check
print(f"\nImport OK: {ProactiveCachePress}")
print(f"Top-level import OK: {_check}")


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 3 — Patch evaluate_registry.py with ProactiveCachePress ║
# ╚══════════════════════════════════════════════════════════════╝
# The registry lives in kvpress/evaluation/ — find it relative to CWD
# (assumes you ran %cd kvpress in Cell 1)

REGISTRY_FILE = pathlib.Path("evaluation/evaluate_registry.py")
if not REGISTRY_FILE.exists():
    REGISTRY_FILE = pathlib.Path("evaluate_registry.py")   # already in evaluation/

registry_text = REGISTRY_FILE.read_text()

if "ProactiveCachePress" not in registry_text:
    # 1. Add import at the top (after TOVAPress import line)
    registry_text = registry_text.replace(
        "    TOVAPress,\n)",
        "    TOVAPress,\n)\nfrom kvpress import ProactiveCachePress",
    )
    # 2. Add entries to PRESS_REGISTRY (before "no_press")
    registry_text = registry_text.replace(
        '    "no_press": None,',
        '    # --- Proactive Cache (S. Khavin, 2025) ---\n'
        '    # https://openreview.net/forum?id=UsdzvxDZUO\n'
        '    "proactive_cache_25": ProactiveCachePress(compression_ratio=0.25),\n'
        '    "proactive_cache_50": ProactiveCachePress(compression_ratio=0.50),\n'
        '    "proactive_cache_75": ProactiveCachePress(compression_ratio=0.75),\n'
        '    "no_press": None,',
    )
    REGISTRY_FILE.write_text(registry_text)
    print(f"Patched: {REGISTRY_FILE}")
else:
    print("Registry already has ProactiveCachePress")


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 4 — Quick sanity check (no model load needed)           ║
# ╚══════════════════════════════════════════════════════════════╝
import torch

press = ProactiveCachePress(compression_ratio=0.75)
print(f"\nPress: {press}")

# Fake keys tensor: (batch=1, kv_heads=8, seq_len=128, head_dim=128)
fake_keys   = torch.randn(1, 8, 128, 128)
fake_values = torch.randn(1, 8, 128, 128)
fake_hidden = torch.randn(1, 128, 4096)

# Mock module with head_dim attribute (required by ScorerPress.compress)
class MockModule:
    head_dim = 128

scores = press.score(MockModule(), fake_hidden, fake_keys, fake_values, None, {})
print(f"Score shape : {scores.shape}")   # expect (1, 8, 128)
print(f"Score dtype : {scores.dtype}")
print(f"Score min/max: {scores.min().item():.4f} / {scores.max().item():.4f}")
print("\nSanity check PASSED.")


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 5 — Set your HuggingFace token                          ║
# ╚══════════════════════════════════════════════════════════════╝
import os
HF_TOKEN = "hf_YOUR_TOKEN_HERE"   # <-- replace this
os.environ["HF_TOKEN"] = HF_TOKEN
os.environ["HUGGING_FACE_HUB_TOKEN"] = HF_TOKEN

MODEL_ID   = "meta-llama/Llama-3.1-8B-Instruct"
DATASET    = "ruler"
OUTPUT_DIR = "./results"
SEED       = 42


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 6 — Run evaluation (exact leaderboard command)          ║
# ║  Runs compression_ratio = 0.25, 0.50, 0.75 + baseline        ║
# ╚══════════════════════════════════════════════════════════════╝
import subprocess, sys

EVAL_SCRIPT = "evaluation/evaluate.py"
if not pathlib.Path(EVAL_SCRIPT).exists():
    EVAL_SCRIPT = "evaluate.py"   # already in evaluation/

def run_eval(press_name, compression_ratio):
    cmd = [
        sys.executable, EVAL_SCRIPT,
        "--press_name",         press_name,
        "--dataset",            DATASET,
        "--model",              MODEL_ID,
        "--compression_ratio",  str(compression_ratio),
        "--output_dir",         OUTPUT_DIR,
        "--seed",               str(SEED),
    ]
    label = f"{press_name}  cr={compression_ratio}"
    print(f"\n{'='*60}\nRunning: {label}\n{'='*60}")
    result = subprocess.run(cmd, text=True)
    if result.returncode != 0:
        print(f"[ERROR] {label} failed (exit {result.returncode})")
    return result.returncode

# Baseline (full attention, no compression)
run_eval("no_press", 0.0)

# ProactiveCachePress at 3 compression ratios
for cr in [0.25, 0.50, 0.75]:
    run_eval(f"proactive_cache_{int(cr*100)}", cr)


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 7 — Collect results and print summary table             ║
# ╚══════════════════════════════════════════════════════════════╝
import json, yaml
import pandas as pd

rows = []
for mf in sorted(pathlib.Path(OUTPUT_DIR).rglob("metrics.json")):
    cf = mf.parent / "config.yaml"
    with open(mf) as f:
        metrics = json.load(f)
    config = {}
    if cf.exists():
        with open(cf) as f:
            config = yaml.safe_load(f) or {}
    rows.append({
        "press":             config.get("press_name", mf.parent.name),
        "compression_ratio": config.get("compression_ratio", "?"),
        "ruler_score":       metrics.get("score", metrics),
        "results_dir":       str(mf.parent),
    })

df = pd.DataFrame(rows).sort_values(["press", "compression_ratio"])
print("\n" + "="*70)
print("  RULER RESULTS  |  ProactiveCachePress vs Baseline")
print("="*70)
print(df.to_string(index=False))
print("="*70)

print("\n--- Raw metrics.json (paste into PR) ---")
for _, row in df.iterrows():
    print(f"\n# {row['press']} | compression_ratio={row['compression_ratio']}")
    if isinstance(row["ruler_score"], dict):
        print(json.dumps(row["ruler_score"], indent=2))
    else:
        print(row["ruler_score"])


# ╔══════════════════════════════════════════════════════════════╗
# ║ CELL 8 — (Reference) exact leaderboard CLI syntax            ║
# ║  Copy-paste into a terminal or %%bash cell                    ║
# ╚══════════════════════════════════════════════════════════════╝
"""
cd kvpress/evaluation

python evaluate.py \
    --press_name proactive_cache_75 \
    --dataset ruler \
    --model meta-llama/Llama-3.1-8B-Instruct \
    --compression_ratio 0.75 \
    --output_dir ./results \
    --seed 42
"""
